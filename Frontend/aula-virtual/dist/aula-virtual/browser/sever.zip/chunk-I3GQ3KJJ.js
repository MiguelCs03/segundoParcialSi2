var e={production:!1,apiUrl:"https://aula-virtual-backend-d3cachhhhcf2fxbn.centralus-01.azurewebsites.net/"};export{e as a};
